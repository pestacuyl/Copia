using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("lolo")]
[assembly: ComVisible(false)]
[assembly: Guid("b803eddd-a64c-4f80-8b82-5864639d404d")]
[assembly: AssemblyFileVersion("1.0.3")]
[assembly: AssemblyDescription("lolo")]
[assembly: AssemblyCompany("lolo")]
[assembly: AssemblyProduct("lolo")]
[assembly: AssemblyCopyright("lolo")]
[assembly: AssemblyTrademark("lolo")]
[assembly: AssemblyVersion("1.0.3")]
