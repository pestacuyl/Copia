using System;

namespace Soph
{
	// Token: 0x02000007 RID: 7
	internal static class RawSettings
	{
		// Token: 0x04000007 RID: 7
		public static string Owner;

		// Token: 0x04000008 RID: 8
		public static string Version;

		// Token: 0x04000009 RID: 9
		public static readonly string SiteUrl = "http://akachoklis.temp.swtest.ru//";

		// Token: 0x0400000A RID: 10
		public static string HWID;
	}
}
