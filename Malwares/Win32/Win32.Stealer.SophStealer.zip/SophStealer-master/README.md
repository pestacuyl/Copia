# SophStealer
https://telegra.ph/Soph---sharp-fork-i-konfyuzer-04-20
