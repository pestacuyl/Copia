﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Support Environment")]
[assembly: ComVisible(false)]
[assembly: Guid("guid")]
[assembly: AssemblyFileVersion("1.0.3")]
[assembly: AssemblyDescription("Support Environment")]
[assembly: AssemblyCompany("Support Environment")]
[assembly: AssemblyProduct("Support Environment")]
[assembly: AssemblyCopyright("Support Environment")]
[assembly: AssemblyTrademark("Support Environment")]
[assembly: AssemblyVersion("1.0.3")]
